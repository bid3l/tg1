
function reload()
  jovetabapi = dofile("./bot/jovetabapi2.lua")
end

reload()
