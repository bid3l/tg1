
token="419567235:AAFgNkZaNYYXs7-_oTFyPtIKyEd0AXNnGa4"

while true; do
./tg -s ./api2.lua -p PROFILE2 --bot=$token
sleep 2
done

