
function reload()
  jovetabapi = dofile("./bot/jovetabapi.lua")
end

reload()
