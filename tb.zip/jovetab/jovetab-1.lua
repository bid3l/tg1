jovetabnum = '1'
function reload()

jovetab = dofile('jovetab.lua')
end
reload()