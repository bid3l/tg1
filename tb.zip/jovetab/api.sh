token="438948653:AAF4jnqVkoHCOjwGP3DtDYsSTBzeYtCg4OM"

while true; do
./tg -s ./api.lua -p PROFILE --bot=$token
sleep 2
done
