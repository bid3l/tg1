while true; do
$(dirname $0)/tg -p jovetab-0 -s jovetab-0.lua
done
