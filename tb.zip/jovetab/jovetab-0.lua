jovetabnum = '0'
function reload()

jovetab = dofile('jovetab.lua')
end
reload()