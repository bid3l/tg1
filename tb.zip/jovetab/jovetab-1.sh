while true; do
$(dirname $0)/tg -p jovetab-1 -s jovetab-1.lua
done
